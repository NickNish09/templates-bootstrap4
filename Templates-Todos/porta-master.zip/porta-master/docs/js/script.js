
$('nav').coreNavigation({
    layout: "sidebar",
    responsideSlide: true 
});
