THEME: Law - Free Bootstrap 4 Theme
AUTHOR: ProBootstrap.com
LICENSE: Under Creative Commons 3.0 (probootstrap.com/license)
AUTHOR URI: https://probootstrap.com/
Twitter: https://twitter.com/probootstrap
Facebook: https://facebook.com/probootstrap

DISTRIBUTOR: Themewagon.com
DISTRIBUTOR URI: https://themewagon.com/
Twitter: https://twitter.com/themewagon
Facebook: https://www.facebook.com/themewagon
Find more free responsive HTML5 templates visit https://themewagon.com/theme_tag/free/

CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Demo Images
https://unsplash.com

WayPoints
http://imakewebthings.com/waypoints/

Animate.css
https://daneden.github.io/animate.css/

Slick Slider
https://kenwheeler.github.io/slick/

FontAwesome
https://fontawesome.com/

Flaticon
https://flaticon

Ionicons
https://ionicons.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/
