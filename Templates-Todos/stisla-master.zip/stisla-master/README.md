

# Stisla
Stisla is HTML5 and CSS3 Template Based on Bootstrap 4

# Features
- No errors (W3C Validator)
- Bootstrap 4
- HTML5 & CSS3
- PHPMailer
- Sweet Alert
- Google maps
- Modern design
- Fully responsive
- Cross-browser compatibility
- Working contact form
- Modal article detail
- Smooth scroll
- Parallax background
- and more ...

# Demo


# Credits
- Bootstrap 4
- jQuery
- jQuery.easeScroll
- Pexels.com
- PHPMailer
- Sweet Alert

# License
MIT License

